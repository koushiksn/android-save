<?php
$db_name="appdb";
$db_user="root";
$db_pass="root";
$db_server="localhost";
$con=mysqli_connect($db_server,$db_user,$db_pass,$db_name);
if(!$con)
{
echo"connection eror".mysqli_connect_error();
}
else
{
echo"success";
}