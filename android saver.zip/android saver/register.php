<?php
require "init.php";
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$pass=$_POST["pass"];
$conpass=$_POST["conpass"];
$sql_query="insert into register values ('$fname','$lname','$email','$pass','$conpass');
if(mysqli_query($con,$sql_query))
{
echo"success"
}
else
{
echo"unsuccess"
}