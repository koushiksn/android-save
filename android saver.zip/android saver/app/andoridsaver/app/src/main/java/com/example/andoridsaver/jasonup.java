package com.example.andoridsaver;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class jasonup extends AsyncTask<String,Void,String> {
    Context cont;
    String data;

    jasonup(Context cont)
    {
        this.cont=cont;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String fname2,lname2,uname2,email2,pass2,conpass2;

        String urlup="http://localhost:8080/register.php";
        String urlin="http://localhost:8080/login.php";
        fname2=params[1];
        lname2=params[2];
        uname2=params[3];
        email2=params[4];
        pass2=params[5];
        conpass2=params[6];
        //Toast.makeText(cont,fname2, Toast.LENGTH_SHORT).show();
        try {
            URL uri= new URL(urlup);
            HttpURLConnection httpURLConnection= (HttpURLConnection) uri.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            OutputStream outputStream =httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
             data = URLEncoder.encode("fname", "UTF-8") + "=" + URLEncoder.encode(fname2,"UTF-8") /*+ "&" +
                    URLEncoder.encode("lname", "UTF-8") + "=" + URLEncoder.encode(lname2, "UTF-8") + "&" +
                    URLEncoder.encode("uname", "UTF-8") + "=" + URLEncoder.encode(uname2, "UTF-8") + "&" +
                    URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email2, "UTF-8") + "&" +
                    URLEncoder.encode("pass", "UTF-8") + "=" + URLEncoder.encode(pass2, "UTF-8") + "&" +
                    URLEncoder.encode("conpass", "UTF-8") + "=" + URLEncoder.encode(conpass2, "UTF-8")*/;
                    bufferedWriter.write(data);

                    bufferedWriter.flush();

                    bufferedWriter.close();
                    outputStream.close();
            InputStream inputStream= httpURLConnection.getInputStream();
            inputStream .close();
            return "success ";


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fname2;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String res) {
        Toast.makeText(cont, res, Toast.LENGTH_SHORT).show();    }
}
