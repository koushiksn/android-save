package com.example.andoridsaver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class signup extends AppCompatActivity {
 EditText fname,lname,uname,email,pass,conpass;
 String fname1,lname1,uname1,email1,pass1,conpass1;
     String meth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        fname = (EditText)findViewById(R.id.ffname);
        lname =(EditText)findViewById(R.id.llname);
        uname =(EditText)findViewById(R.id.uuname);
        email= (EditText)findViewById(R.id.eemail);
        pass=(EditText)findViewById(R.id.ppass);
        conpass=(EditText)findViewById(R.id.cconfpass);
    }

    public void save(View view) {
        fname1 = fname.getText().toString().trim();
        lname1=lname.getText().toString().trim();
        uname1=uname.getText().toString().trim();
        email1=email.getText().toString().trim();
        pass1=pass.getText().toString().trim();
        conpass1=conpass.getText().toString().trim();
meth="signup";
jasonup jup=new jasonup(this);
jup.execute(meth,fname1,lname1,uname1,email1,pass1,conpass1);

finish();

    }
}
